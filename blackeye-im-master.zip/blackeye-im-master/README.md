
  

<p align="left">
<a href="#"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-green?colorA=%23ff9933&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="blackeye-im" src="https://i.imgur.com/5N5Kdjw.png"></a>
</p>
<p align="center">
<a href="https://github.com/thewickedkarma"><img title="Author" src="https://img.shields.io/badge/Author-thewickedkarma-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
<a href="#"><img title="Language" src="https://img.shields.io/badge/Shell-555555?style=for-the-badge&logo=shell&logoColor=white"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-2.5-green.svg?style=flat-square"></a>
<a href="https://github.com/thewickedkarma/followers"><img title="Followers" src="https://img.shields.io/github/followers/thewickedkarma?color=blue&style=flat-square"></a>
<a href="https://github.com/thewickedkarma/blackeye-im/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/thewickedkarma/blackeye-im?color=red&style=flat-square"></a>
<a href="https://github.com/thewickedkarma/blackeye-im/network/members"><img title="Forks" src="https://img.shields.io/github/forks/thewickedkarma/blackeye-im?color=red&style=flat-square"></a>
<a href="https://github.com/thewickedkarma/blackeye-im/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/thewickedkarma/blackeye-im?label=Watchers&color=blue&style=flat-square"></a>
</p>












# BLACKEYE v2.5
<ul type='disc'> <li>Added new port forwarding method 'Localtunnel' (might have some issues)
<li>Link shortening using Bitly and Tinyurl API
<li>Location Tracing based on IP address (includes google map)


</ul>
 <a href="#"><img title="blackeye-im" width= "20%" src="https://i.imgur.com/5N5Kdjw.png"></a>


# Blackeye-im

Ultimate phishing tool powered by ngrok (<a href='https://thewickedkarma.github.io/blackeye-im'>Know More</a>)

# Installation (for linux):
```
git clone https://github.com/thewickedkarma/blackeye-im.git
cd blackeye-im
chmod +x ./setup.sh
./setup.sh
```
Usage:

```./blackeye.sh```
<p><a href="https://i.imgur.com/irdzUjd.png"><img title="blackeye-im" src="https://i.imgur.com/irdzUjd.png"></a>
</p>

# Android (termux and equivalents).
```
git clone https://github.com/thewickedkarma/blackeye-im.git
cd blackeye-im
chmod +x ./tmxsp.sh
```
Usage:

```./tmxsp.sh```
<p><a href="#"><img title="blackeye-im" src="https://i.imgur.com/YuAb55M.jpg"></a>
</p>
Note: Made for Educational Purposes,use it with mutual consent of the victim.
<p><a href="https://i.imgur.com/TJFmaGq.png"><img title="blackeye-im" src="https://i.imgur.com/TJFmaGq.png"></a>
</p>

 

-----------------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------


## Legal disclaimer:

Usage of BlackEye for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. Only use for educational purposes.


## Contact:
<p align="center">
    <a href="https://www.instagram.com/thewickedkarma/">
    <img alt="Instagram" src="https://img.shields.io/badge/Instagram%20-%23000000.svg?&style=for-the-badge&logo=Instagram&logoColor=white"/></a>
    <a href="https://twitter.com/Ankitraj7079">
    <img alt="Twitter" src="https://img.shields.io/badge/Twitter%20-%231DA1F2.svg?&style=for-the-badge&logo=Twitter&logoColor=white"</a>
    <a href="https://discord.com/channels/@me/798505744843538432">
    <img alt="Discord" src="https://img.shields.io/badge/Discord%20-%237289DA.svg?&style=for-the-badge&logo=discord&logoColor=white"/></a>
</p>
