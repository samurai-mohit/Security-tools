## 2022.2.19

- 新增PhoneBook、Snov搜集模块，数据结果更全！！！

![PhoneBook&Snov_result](../img/PhoneBook&Snov.png)

![PhoneBook&Snov_result](../img/PhoneBook&Snov_result.png)

## 2022.2.16

- 新增Github搜集模块，更全！！！

![githubapi.png](../img/githubapi.png)

## 2022.2.14

- [EmaiAll](https://github.com/Taonn/EmailAll)发布