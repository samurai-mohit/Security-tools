class Options:
    '''
    Scan even if the site is not protected
    '''
    SCAN_ANYWAY = False

    '''
    Do not check for matches. Just scan everything
    '''
    SCAN_EVERYTHING = False
