# cignotrack

Corporate espionage tool for testing privacy and security 
using OSINT and social engineering.

Cignotrack has this features:

- Extract and analyze the target images and documents metadata
- Discover whois, IP and technologies related informations
- Search target emails and social media tracking
- Search for sensitive files
- Tracking the target internet search (DNS cache snooping)
- Phishing with preloaded scenarios

Tool coded for security testing, the author decline any illegal use of this tool.

Coded by Cignoraptor.

Maybe in your machine you need install: 
links2 (sudo apt-get install links2) 
whois (sudo apt-get install whois)
exiftool (sudo apt-get install libimage-exiftool-perl)
sendemail (sudo apt-get install sendemail)

Usage: bash cignotrack.sh   
WARNING: Not use a url like target but a domain!
PS: DOMAIN!!!
Exemple: organizzazione.net -----> This is a domain!

Tool coded for security test, The author decline any responsability for any illegal use of this tool, use at your own risk.
