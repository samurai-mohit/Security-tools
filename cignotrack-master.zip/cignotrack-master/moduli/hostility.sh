#!/bin/bash

echo -e "\e[00;31mThis module is temporarily suspended!\e[00m"
