Troubleshooting
===============

* In very large websites you can get too many directories and fill up the RAM.
* Dirhunt can enter directory loops
