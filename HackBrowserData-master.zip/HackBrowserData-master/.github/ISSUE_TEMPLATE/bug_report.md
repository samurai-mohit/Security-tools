---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Describe the bug**
Use `./hack-browser-data -vv` paste result here


**Desktop (please complete the following information):**
 - OS Name: 
 - Browser Name:
 - Browser Version:

**Additional context**
Add any other context about the problem here.
