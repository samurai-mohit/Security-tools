#include "file.h"
#include "tcp_sock.h"
char recvbuff[128];
char filebuff[255];
int tmp;
int result;
int closed;
